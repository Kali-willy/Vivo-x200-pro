#!/system/bin/sh
# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

MODDIR=${0%/*}

# Set permissions
chmod 644 $MODDIR/system.prop

# Create log directory
mkdir -p $MODDIR/logs

# Log module start
echo "Device Spoof Module started at $(date)" > $MODDIR/logs/post-fs-data.log

# Apply additional device spoofing if needed
resetprop -n ro.product.manufacturer vivo
resetprop -n ro.product.brand vivo
resetprop -n ro.product.name V2339
resetprop -n ro.product.device V2339
resetprop -n ro.product.model V2339
resetprop -n ro.build.product V2339
resetprop -n ro.vivo.product.model V2339
resetprop -n ro.vivo.hardware.version PD2339F_EX
resetprop -n ro.vivo.product.release.name V2339
resetprop -n ro.vivo.market.name "VIVO X200 Pro"

# Log current device properties
echo "Current device properties after post-fs-data:" >> $MODDIR/logs/post-fs-data.log
getprop | grep -E 'product|brand|model|device' >> $MODDIR/logs/post-fs-data.log 