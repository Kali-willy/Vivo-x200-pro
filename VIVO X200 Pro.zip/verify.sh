#!/system/bin/sh

##########################
# Verifier
##########################

# Global vars
TMPDIR=/dev/tmp
MAGISKBIN=/data/adb/magisk

# Set permissions
set_perm() {
  chown $2:$3 $1 || return 1
  chmod $4 $1 || return 1
  [ -z $5 ] && return 0 || chcon $5 $1 || return 1
}

set_perm_recursive() {
  find $1 -type d 2>/dev/null | while read dir; do
    set_perm $dir $2 $3 $4 $6
  done
  find $1 -type f -o -type l 2>/dev/null | while read file; do
    set_perm $file $2 $3 $5 $6
  done
}

# Mount partitions
mount_partitions() {
  # Check A/B slot
  SLOT=`getprop ro.boot.slot_suffix`
  if [ -z $SLOT ]; then
    SLOT=_`getprop ro.boot.slot`
    [ $SLOT = "_" ] && SLOT=
  fi
  [ -z $SLOT ] || ui_print "- Current boot slot: $SLOT"
  ui_print "- Mounting /system, /vendor"
  REALSYS=/system
  [ -f /system/build.prop ] || is_mounted /system || mount -o rw /system 2>/dev/null
  if ! is_mounted /system && ! [ -f /system/build.prop ]; then
    SYSTEMBLOCK=`find /dev/block -iname system$SLOT | head -n 1`
    mount -t ext4 -o rw $SYSTEMBLOCK /system
  fi
  [ -f /system/build.prop ] || is_mounted /system || abort "! Cannot mount /system"
  cat /proc/mounts | grep -E '/dev/root|/system_root' >/dev/null && SYSTEM_ROOT=true || SYSTEM_ROOT=false
  if [ -f /system/init ]; then
    SYSTEM_ROOT=true
    mkdir /system_root 2>/dev/null
    mount --move /system /system_root
    mount -o bind /system_root/system /system
    ROOT=/system_root
    REALSYS=/system_root/system
  fi
  $SYSTEM_ROOT && ui_print "- System-as-root detected"
  [ -L /system/vendor ] && VEN=/vendor
  [ -L /system/product ] && PRODUCT=/product
  [ -L /system/system_ext ] && SYSTEM_EXT=/system_ext
  if [ $API -ge 28 ]; then
    [ -e /system/product ] && PRODUCT=/system/product
    [ -e /system/system_ext ] && SYSTEM_EXT=/system/system_ext
    [ -e /system/vendor ] && VEN=/system/vendor
  fi
}

# Check if the device is encrypted
check_encryption() {
  # Is boot device encrypted?
  if grep ' /data ' /proc/mounts | grep -q 'dm-'; then
    ui_print "- Data partition is encrypted"
    ISENCRYPTED=true
  else
    ISENCRYPTED=false
  fi
}

# Extract the module files
extract_module() {
  ui_print "- Extracting module files"
  unzip -o "$ZIP" -d $MODPATH >&2
  
  # Set permissions
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/service.sh 0 0 0755
  set_perm $MODPATH/post-fs-data.sh 0 0 0755
}

# Main
OUTFD=$2
ZIPFILE=$3

mount_partitions
check_encryption
extract_module

ui_print "- Verification completed" 