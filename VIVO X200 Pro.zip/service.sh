#!/system/bin/sh
# This script will be executed in late_start service mode
# More info in the main Magisk thread

MODDIR=${0%/*}

# Create log directory if it doesn't exist
mkdir -p $MODDIR/logs

# Log module start
echo "Device Spoof Module service started at $(date)" > $MODDIR/logs/service.log

# Apply additional device spoofing at runtime
resetprop -n ro.product.manufacturer vivo
resetprop -n ro.product.brand vivo
resetprop -n ro.product.name V2339
resetprop -n ro.product.device V2339
resetprop -n ro.product.model V2339
resetprop -n ro.build.product V2339
resetprop -n ro.vivo.product.model V2339
resetprop -n ro.vivo.hardware.version PD2339F_EX
resetprop -n ro.vivo.product.release.name V2339
resetprop -n ro.vivo.market.name "VIVO X200 Pro"

# Log current device properties
echo "Current device properties after service start:" >> $MODDIR/logs/service.log
getprop | grep -E 'product|brand|model|device' >> $MODDIR/logs/service.log

# Additional spoofing for apps that check device info at runtime
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 1
done

# Final check after boot completed
echo "Boot completed at $(date)" >> $MODDIR/logs/service.log
echo "Final device properties:" >> $MODDIR/logs/service.log
getprop | grep -E 'product|brand|model|device' >> $MODDIR/logs/service.log

# Ensure the spoofing persists
resetprop -n ro.product.manufacturer vivo
resetprop -n ro.product.brand vivo
resetprop -n ro.product.name V2339
resetprop -n ro.product.device V2339
resetprop -n ro.product.model V2339
resetprop -n ro.build.product V2339 