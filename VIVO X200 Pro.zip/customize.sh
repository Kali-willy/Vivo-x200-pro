#!/system/bin/sh
# Do NOT assume where your module will be located
# ALWAYS use $MODPATH if you need to know where this script
# and module is placed.
# This will make sure your module will work
# if Magisk changes its mount point in the future

MODPATH=${0%/*}

# Set what you want to display when installing your module
ui_print "******************************"
ui_print "* Device Spoof Module        *"
ui_print "* Author: willygailo01@gmail.com *"
ui_print "* Compatible with Magisk v29000+ *"
ui_print "* For Android 10+ devices    *"
ui_print "******************************"

# Create system.prop file with device spoofing properties
cat << EOF > $MODPATH/system.prop
# VIVO X200 Pro properties
ro.product.manufacturer=vivo
ro.product.brand=vivo
ro.product.name=V2339
ro.product.device=V2339
ro.product.model=V2339
ro.build.product=V2339
ro.vivo.product.model=V2339
ro.vivo.hardware.version=PD2339F_EX
ro.vivo.product.release.name=V2339
ro.vivo.market.name=VIVO X200 Pro

# Additional device spoofing options for other brands
# Uncomment and modify as needed

# Samsung properties
#ro.product.manufacturer=samsung
#ro.product.brand=samsung
#ro.product.name=SM-G998B
#ro.product.device=SM-G998B
#ro.product.model=SM-G998B
#ro.build.product=SM-G998B

# Realme properties
#ro.product.manufacturer=realme
#ro.product.brand=realme
#ro.product.name=RMX3312
#ro.product.device=RMX3312
#ro.product.model=RMX3312
#ro.build.product=RMX3312

# Redmi properties
#ro.product.manufacturer=Xiaomi
#ro.product.brand=Redmi
#ro.product.name=K50
#ro.product.device=K50
#ro.product.model=Redmi K50
#ro.build.product=K50

# Infinix properties
#ro.product.manufacturer=INFINIX
#ro.product.brand=INFINIX
#ro.product.name=X665C
#ro.product.device=X665C
#ro.product.model=Infinix HOT 12
#ro.build.product=X665C
EOF

# Create post-fs-data.sh script
cat << 'EOF' > $MODPATH/post-fs-data.sh
#!/system/bin/sh
# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

# Set permissions
chmod 644 $MODPATH/system.prop
EOF

# Create service.sh script
cat << 'EOF' > $MODPATH/service.sh
#!/system/bin/sh
# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Additional runtime device spoofing if needed
MODPATH=${0%/*}

# Log the current spoofed device info
log_file=$MODPATH/spoof_log.txt
echo "Device Spoof Module activated at $(date)" > $log_file
echo "Current device properties:" >> $log_file
getprop | grep -E 'product|brand|model|device' >> $log_file
EOF

# Set executable permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755

# Set PROPFILE to true to enable system.prop
PROPFILE=true
# Set AUTOMOUNT to true to enable auto mounting
AUTOMOUNT=true
# Set POSTFSDATA to true to enable post-fs-data script
POSTFSDATA=true
# Set LATESTARTSERVICE to true to enable late_start service script
LATESTARTSERVICE=true 